% Created by txt2dlm for Matlab7.
header = {
  'ID'
  'Factor1'
  'Factor2'
  'Factor3'
  'Serum1'
  'Serum2'
  'Serum3'
  'Serum4'
  'Serum5'
  'Urine1'
  'Urine2'
  'Urine3'
  'Urine4'
  'Categ1'
  'Diagn1'
  'Diagn2'
  'Body1'
  'Body2'
  'Body3'
}';
data = load('dataset.dlm');
