function [Index]=getindex(S,subsetS)
%+++ Find the index of each element of subsetS in S.

Index=[];
for i=1:length(subsetS);
  [VName,temp]=intersect(lower(S),lower(subsetS{i}));
  if isempty(temp);temp=NaN;end
  Index=[Index;temp];     
end


