step 1: run som_demo_script.m  to get SOM results
step 2: run gen_som_geneset.pl to get gene set in each cell of SOM
step 3: run gen_som_geneset.pl to get Gene Ontology enrichment results

note: in step 3, please set up the Java version of GoTermFinder first.